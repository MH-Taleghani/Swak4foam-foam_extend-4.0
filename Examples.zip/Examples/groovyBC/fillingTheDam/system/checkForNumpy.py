try:
    import numpy
    return True
except ImportError:
    return False
