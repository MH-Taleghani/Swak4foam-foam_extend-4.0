#! /bin/sh

funkySetFields -time 0
