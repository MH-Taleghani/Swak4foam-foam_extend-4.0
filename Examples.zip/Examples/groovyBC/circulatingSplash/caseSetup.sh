#! /bin/sh

funkySetFields -time 0 -allowFunctionObjects -addDummyPhi
