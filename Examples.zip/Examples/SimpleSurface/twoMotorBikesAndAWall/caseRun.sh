#!/bin/sh
# Source tutorial run functions

potentialFoam -writep -noFunctionObjects

simpleFoam
