# import scipy.stats
from matplotlib import pyplot

times=[]
slopes=[]
offsets=[]

print dir()
# pyplot.xkcd()

index=0