#! /bin/sh

blockMesh

topoSet
setsToZones
