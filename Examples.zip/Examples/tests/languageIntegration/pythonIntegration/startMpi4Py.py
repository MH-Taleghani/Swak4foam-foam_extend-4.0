print "Initializing mpi4py"

from mpi4py import MPI

comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()

cnt=1

print "mpi4py - start",size,rank
