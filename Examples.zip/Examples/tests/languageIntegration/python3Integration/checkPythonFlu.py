try:
    import Foam
    return True
except ImportError:
    return False
    