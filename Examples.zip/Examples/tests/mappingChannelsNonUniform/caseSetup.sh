#! /bin/sh

calcNonUniformOffsetsForMapped

funkySetFields -time 0
