#!/bin/sh

blockMesh
topoSet
