#! /bin/sh

ansysToFoam flange.ans -scale 0.001
