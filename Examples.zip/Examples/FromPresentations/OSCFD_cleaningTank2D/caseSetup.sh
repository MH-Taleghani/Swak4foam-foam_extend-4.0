#! /bin/sh

funkySetFields -functionPlugins MeshWave -time 0
