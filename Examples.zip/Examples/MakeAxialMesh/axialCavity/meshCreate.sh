#! /bin/sh

blockMesh
makeAxialMesh -overwrite
