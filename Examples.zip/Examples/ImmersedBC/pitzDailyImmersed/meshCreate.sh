#! /bin/sh

blockMesh
cp save/boundary constant/polyMesh/
