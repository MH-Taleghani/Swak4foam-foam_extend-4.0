#! /bin/sh

blockMesh

makeFaMesh
