/*---------------------------------------------------------------------------*\
|                       _    _  _     ___                       | The         |
|     _____      ____ _| | _| || |   / __\__   __ _ _ __ ___    | Swiss       |
|    / __\ \ /\ / / _` | |/ / || |_ / _\/ _ \ / _` | '_ ` _ \   | Army        |
|    \__ \\ V  V / (_| |   <|__   _/ / | (_) | (_| | | | | | |  | Knife       |
|    |___/ \_/\_/ \__,_|_|\_\  |_| \/   \___/ \__,_|_| |_| |_|  | For         |
|                                                               | OpenFOAM    |
-------------------------------------------------------------------------------
License
    This file is part of swak4Foam.

    swak4Foam is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    swak4Foam is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with swak4Foam; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Contributors/Copyright:
    2012-2013, 2016-2018 Bernhard F.W. Gschaider <bgschaid@hfd-research.com>
    2017 Mark Olesen <Mark.Olesen@esi-group.com>

 SWAK Revision: $Id$
\*---------------------------------------------------------------------------*/

#include "randomExponentialPluginFunction.H"
#include "FieldValueExpressionDriver.H"
#include "FieldValuePluginFunction.H"
#include <Random.H>

#include "addToRunTimeSelectionTable.H"

namespace Foam {

typedef randomExponentialPluginFunction<FieldValuePluginFunction,FieldValueExpressionDriver> randomExponentialPluginFunctionField;
defineTemplateTypeNameAndDebug(randomExponentialPluginFunctionField,0);

addNamedToRunTimeSelectionTable(FieldValuePluginFunction, randomExponentialPluginFunctionField , name, randomExponential);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

template <typename FType,typename DType>
randomExponentialPluginFunction<FType,DType>::randomExponentialPluginFunction(
    const DType &parentDriver,
    const word &name
):
    FType(
        parentDriver,
        name,
        word("volScalarField"),
        string("seed primitive label,halfLife primitive scalar")
    ),
    halfLife_(1),
    seed_(666)
{
}

// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template <typename FType,typename DType>
void randomExponentialPluginFunction<FType,DType>::doEvaluationInternal(
    scalarField &f
) {
    label seed=seed_;

    if(seed<=0) {
        seed=this->mesh().time().timeIndex()-seed;
    }

    Random rnd(seed);

    forAll(f,i) {
#ifdef FOAM_RANDOM_CLASS_NEW_INTERFACE
        f[i]=-log(1-rnd.sample01<scalar>())*halfLife_;
#else
        f[i]=-log(1-rnd.scalar01())*halfLife_;
#endif
    }
}

template <typename FType,typename DType>
void randomExponentialPluginFunction<FType,DType>::doEvaluation()
{
    autoPtr<volScalarField> pRandom(
        new volScalarField(
            IOobject(
                "exponentialRandom",
                this->mesh().time().timeName(),
                this->mesh(),
                IOobject::NO_READ,
                IOobject::NO_WRITE
            ),
            this->mesh(),
            dimensionedScalar("randomExp",dimless,0),
            "zeroGradient"
        )
    );

    doEvaluationInternal(
#ifdef FOAM_NO_DIMENSIONEDINTERNAL_IN_GEOMETRIC
        const_cast<scalarField&>(pRandom->internalField().field())
#else
        pRandom->internalField()
#endif
    );

    this->result().setObjectResult(pRandom);
}

template <typename FType,typename DType>
void randomExponentialPluginFunction<FType,DType>::setArgument(
    label index,
    const label &val
)
{
    assert(index==0);
    seed_=val;
}

template <typename FType,typename DType>
void randomExponentialPluginFunction<FType,DType>::setArgument(
    label index,
    const scalar &val
)
{
    assert(index==1);
    halfLife_=val;
}

// * * * * * * * * * * * * * * * Friend Operators  * * * * * * * * * * * * * //

} // namespace

// ************************************************************************* //
