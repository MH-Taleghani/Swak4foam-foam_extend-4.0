lua_interpreter = "lua"
rocks_trees = {
   {
      name = "user",
      root = "/home/mrnone/.luarocks"
   },
   {
      name = "system",
      root = "/home/mrnone/foam/swak4Foam/privateRequirements"
   }
}
variables = {
   LUA_BINDIR = "/home/mrnone/foam/swak4Foam/privateRequirements/bin",
   LUA_DIR = "/home/mrnone/foam/swak4Foam/privateRequirements",
   LUA_INCDIR = "/home/mrnone/foam/swak4Foam/privateRequirements/include"
}
